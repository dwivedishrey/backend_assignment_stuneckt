import React from 'react'
import '../pages.css'

function Explore() {
    return (
        <div className='page'>
            <h2 className='pageTitle'>Welcome to Explore page</h2>
        </div>
    )
}

export default Explore