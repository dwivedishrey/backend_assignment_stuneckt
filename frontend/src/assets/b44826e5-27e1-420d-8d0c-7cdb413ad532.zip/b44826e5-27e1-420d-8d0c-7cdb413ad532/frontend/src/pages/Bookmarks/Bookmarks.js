import React from 'react'
import '../pages.css'

function Bookmarks() {
    return (
        <div className='page'>
            <h2 className='pageTitle'>Welcome to Bookmark page</h2>
        </div>
    )
}

export default Bookmarks