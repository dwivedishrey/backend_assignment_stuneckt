# Twitter Clone

The clone version of `Twitter`.

### `List of technologies`

`ReactJs`, `NodeJs`, `ExpressJs`, `MongoDB`, `Firebase`, `Material UI`.

### `About this project `

The `Twitter Clone` project is build with a team for learning purpose. Where the key goal was learning to build a professional application.
